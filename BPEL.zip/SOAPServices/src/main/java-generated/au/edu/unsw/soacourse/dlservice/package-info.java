@javax.xml.bind.annotation.XmlSchema(namespace = "http://dlservice.soacourse.unsw.edu.au")
package au.edu.unsw.soacourse.dlservice;
